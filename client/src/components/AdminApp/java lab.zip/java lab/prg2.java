import java.io.BufferedReader;
import java.io.FileReader;
public class prg2 {
    public static void main(String[] args) throws Exception {
        int charCount = 0, wordCount = 0, lineCount = 0;
        BufferedReader reader = new BufferedReader(new FileReader("ex1.txt"));
        String line;
        while ((line = reader.readLine()) != null) {
            lineCount++;
            charCount += line.length();
            String[] words = line.trim().split("\\s+");
            if (words.length > 0 && !words[0].isEmpty()) {
                wordCount += words.length;
            }
        }
        reader.close();
        System.out.println("Number of characters: " + charCount);
        System.out.println("Number of words: " + wordCount);
        System.out.println("Number of lines: " + lineCount);
    }
}
