import java.io.*;
import java.util.Scanner;
class Student implements Serializable {
    public String rno;
    public String name;

    public Student(String rno, String name) {
        this.rno = rno;
        this.name = name;
    }

    public String toString() {
        return "ROLL NO=" + rno + " NAME=" + name;
    }
}
public class prg4 {
    public static void main(String[] args) throws Exception {
        File file = new File("student.dat");

        if (!file.exists()) {
            ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(file));
            Student[] students = {
                new Student("19BD1A0401", "Aryan"),
                new Student("19BD1A0402", "Varun"),
                new Student("19BD1A0403", "Riya"),
                new Student("19BD1A0404", "Ananya")
            };
            for (Student student : students) {
                output.writeObject(student);
            }
            output.close();
        }
        ObjectInputStream input = new ObjectInputStream(new FileInputStream("student.dat"));
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter roll number: ");
        String rollNumber = scanner.nextLine();
        boolean found = false;
        try {
            while (true) {
                Student student = (Student) input.readObject();
                if (student.rno.equals(rollNumber)) {
                    System.out.println("Student name: " + student.name);
                    found = true;
                    break;
                }
            }
        } catch (EOFException e) {
            if (!found) {
                System.out.println("No such student found");
            }
        } finally {
            input.close();
            scanner.close();
        }
    }
}
