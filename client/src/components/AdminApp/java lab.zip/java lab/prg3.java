import java.io.*;
public class prg3 {
    public static void main(String[] args) throws Exception {
        BufferedReader inputFile = new BufferedReader(new FileReader("file1.dat"));
        BufferedWriter evenFile = new BufferedWriter(new FileWriter("even.dat"));
        BufferedWriter oddFile = new BufferedWriter(new FileWriter("odd.dat"));
        String line;
        while ((line = inputFile.readLine()) != null) {
            String[] numbers = line.split("\\s+");
            for (String numStr : numbers) {
                int num = Integer.parseInt(numStr);
                if (num % 2 == 0) {
                    evenFile.write(num + " ");
                } else {
                    oddFile.write(num + " ");
                }
            }
        }
        inputFile.close();
        evenFile.close();
        oddFile.close();
        BufferedReader oddReader = new BufferedReader(new FileReader("odd.dat"));
        System.out.print("The odd numbers from odd.dat file: ");
        while ((line = oddReader.readLine()) != null) {
            System.out.print(line);
        }
        oddReader.close();
    }
}
