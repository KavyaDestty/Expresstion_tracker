import java.io.FileReader;
import java.io.IOException;
public class prg1 {
    public static void main(String[] args) {
        try (FileReader reader = new FileReader("ex1.txt")) {
            int ch;
            while ((ch = reader.read()) != -1) {
                char character = (char) ch;
                if (Character.isLowerCase(character)) {
                    character = Character.toUpperCase(character);
                }
                System.out.print(character);
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
        }
    }
}
